# Notes-Sharing-Web-Application-using-Django-Framework---Jawaharlalnehru_M-3033-JCTCET-
Notes Sharing Web Application using Django Framework 
Installation 📦
To install Django Music Player, follow these steps:
1. Clone this repository:
   
2. Navigate to the project directory:
  cd Django-MusicPlayer
3 . Create a virtual environment:
  python3 -m venv env
4. Activate the virtual environment:
  source env/bin/activate
5. Install the project dependencies:
  pip install -r requirements.txt
6 . Run the server
  python manage.py runserver
7 . Go to localhost:8000
